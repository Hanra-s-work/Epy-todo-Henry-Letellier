/*
** EPITECH PROJECT, 2022
** space-track-home (Workspace)
** File description:
** sleep.js
*/

function sleep(delay, command) {
    setTimeout(command(), delay);
}
