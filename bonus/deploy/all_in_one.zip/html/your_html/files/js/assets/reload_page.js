/*
** EPITECH PROJECT, 2022
** space-track-home (Workspace)
** File description:
** reload_page.js
*/

function reload_page(keep_cache = false) {
    location.reload(keep_cache);
}
