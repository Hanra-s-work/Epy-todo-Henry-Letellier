#!/bin/bash
echo off
color 0A
echo "(c) Created by Henry Letellier and Harleen Singh-Kaur"
echo "Starting program..."
sudo docker-compose up
