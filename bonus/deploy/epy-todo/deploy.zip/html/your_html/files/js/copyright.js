/*
** EPITECH PROJECT, 2022
** space-track-home (Workspace)
** File description:
** copyright.js
*/

function copyright(ID) {
    var copyright_sentence = "<p class='copyright'>&copy; Created with &hearts; by Henry Letellier and Harleen Singh-Kaur</p>";
    document.getElementById(ID).innerHTML = copyright_sentence;
}
