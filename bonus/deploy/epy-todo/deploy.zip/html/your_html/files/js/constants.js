var node_url = "http://localhost:3000"
let token = '';
let token_cookie_name = "login_token"
